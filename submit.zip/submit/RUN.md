# RUN.md - HW1 Experiment Commands

This document contains the commands to reproduce results for Behavioral Cloning (BC) and DAgger experiments.

---

## **Q1: Behavioral Cloning (BC)**

To generate the results for Question 1.1 Part 2 the following commands were ran:

### **Ant**
```bash
python rob831/scripts/run_hw1.py --expert_policy_file rob831/policies/experts/Ant.pkl --env_name Ant-v2 --exp_name bc_ant --n_iter 1 --expert_data rob831/expert_data/expert_data_Ant-v2.pkl --no_gpu
```

### **Humanoid**
```bash
python rob831/scripts/run_hw1.py --expert_policy_file rob831/policies/experts/Humanoid.pkl --env_name Humanoid-v2 --exp_name bc_humanoid --n_iter 1 --expert_data rob831/expert_data/expert_data_Humanoid-v2.pkl  --no_gpu
```

### **Walker2D**
```bash
python rob831/scripts/run_hw1.py --expert_policy_file rob831/policies/experts/Walker2d.pkl --env_name Walker2d-v2 --exp_name bc_walker2d --n_iter 1 --expert_data rob831/expert_data/expert_data_Walker2d-v2.pkl --no_gpu
```

### **Hopper**
```bash
python rob831/scripts/run_hw1.py --expert_policy_file rob831/policies/experts/Hopper.pkl --env_name Hopper-v2 --exp_name bc_hopper --n_iter 1 --expert_data rob831/expert_data/expert_data_Hopper-v2.pkl --no_gpu
```

### **HalfCheetah**
```bash
python rob831/scripts/run_hw1.py --expert_policy_file rob831/policies/experts/HalfCheetah.pkl --env_name HalfCheetah-v2 --exp_name bc_halfcheetah --n_iter 1 --expert_data rob831/expert_data/expert_data_HalfCheetah-v2.pkl --no_gpu
```


To generate the results for Question 1.2 Part 3, the following commands were ran for the Ant and Humanoid environment:


```bash
python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Ant.pkl \
--env_name Ant-v2 --exp_name bc_ant --n_iter 1 \
--expert_data rob831/expert_data/expert_data_Ant-v2.pkl \
--eval_batch_size 5000 --no_gpu
```

```bash
python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Humanoid.pkl \
--env_name Humanoid-v2 --exp_name bc_humanoid --n_iter 1 \
--expert_data rob831/expert_data/expert_data_Humanoid-v2.pkl \
--eval_batch_size 5000 --no_gpu 
```


To generate the results for Question 1.3 Part 4, the following command was ran for the Humanoid environment:

```bash
python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Humanoid.pkl \
--env_name Humanoid-v2 --exp_name bc_humanoid --n_iter 1 \
--expert_data rob831/expert_data/expert_data_Humanoid-v2.pkl \
--eval_batch_size 5000 --no_gpu \
--train_batch_size 10

python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Humanoid.pkl \
--env_name Humanoid-v2 --exp_name bc_humanoid --n_iter 1 \
--expert_data rob831/expert_data/expert_data_Humanoid-v2.pkl \
--eval_batch_size 5000 --no_gpu \
--train_batch_size 100

python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Humanoid.pkl \
--env_name Humanoid-v2 --exp_name bc_humanoid --n_iter 1 \
--expert_data rob831/expert_data/expert_data_Humanoid-v2.pkl \
--eval_batch_size 5000 --no_gpu \
--train_batch_size 1000

python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Humanoid.pkl \
--env_name Humanoid-v2 --exp_name bc_humanoid --n_iter 1 \
--expert_data rob831/expert_data/expert_data_Humanoid-v2.pkl \
--eval_batch_size 5000 --no_gpu \
--train_batch_size 10000

python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Humanoid.pkl \
--env_name Humanoid-v2 --exp_name bc_humanoid --n_iter 1 \
--expert_data rob831/expert_data/expert_data_Humanoid-v2.pkl \
--eval_batch_size 5000 --no_gpu \
--train_batch_size 100000

```

---

## **Q2: DAgger**

To generate the data seen in the chart in Question 2.1 Part 2, run the following:

### **Ant**
```bash
python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Ant.pkl \
--env_name Ant-v2 --exp_name dagger_ant --n_iter 100 \
--do_dagger --expert_data rob831/expert_data/expert_data_Ant-v2.pkl \
--video_log_freq -1 --no_gpu
```

### **Humanoid**
```bash
python rob831/scripts/run_hw1.py \
--expert_policy_file rob831/policies/experts/Humanoid.pkl \
--env_name Humanoid-v2 --exp_name dagger_humanoid --n_iter 100 \
--do_dagger --expert_data rob831/expert_data/expert_data_Humanoid-v2.pkl \
--video_log_freq -1 --no_gpu
```

---
